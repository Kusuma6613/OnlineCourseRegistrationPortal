<?php
session_start();
include('includes/config.php');
if (isset($_POST['submit'])) {
    $enteredPin = $_POST['pincode'];
    // Update the 'parent' column in the database
    $sql1 = "SELECT * from students where pincode = '$enteredPin'";
    // $sql2 = "SELECT students.pincode
    //         FROM students
    //         LEFT JOIN courseenrolls ON students.pincode = courseenrolls.pincode
    //         WHERE (courseenrolls.pincode IS NULL) OR (courseenrolls.parent = 1)";
    $sql2 = "SELECT * FROM courseenrolls WHERE pincode = '$enteredPin' AND parent = 0";
    $result1 = mysqli_query($bd, $sql1);
    if($result1){
        $result2 = mysqli_query($bd, $sql2);
        if(mysqli_num_rows($result2) > 0){
                // Display the approve button if the PIN is valid
                $row = mysqli_fetch_assoc($result2);
                $studentId = $row['studentRegno']; // Replace 'student_id' with the actual column name
        
                echo "<form method='post'>";
                echo "<input type='hidden' name='studentRegno' value='$studentId'>";
                // echo "<input type='submit' name='approve' value='Approve'>";
                echo "</form>";
        }
        else{
            $_SESSION['msg'] = "Invalid PIN or Approved Already";
        }
    }
    
    // if (mysqli_num_rows($result) > 0) {
    //     // Display the approve button if the PIN is valid
    //     $row = mysqli_fetch_assoc($result);
    //     $studentId = $row['studentRegno']; // Replace 'student_id' with the actual column name

    //     echo "<form method='post'>";
    //     echo "<input type='hidden' name='studentRegno' value='$studentId'>";
    //     // echo "<input type='submit' name='approve' value='Approve'>";
    //     echo "</form>";
    // } else {
    //     $_SESSION['msg'] = "Invalid PIN or Approved Already";
    // }
}
if (isset($_POST['approve'])) {
    $studentId = $_POST['studentRegno'];
    $query = "UPDATE courseenrolls SET parent = 1 WHERE studentRegno = '$studentId'";
    $result = mysqli_query($bd, $query);
    if ($result) {
        $_SESSION['msg'] = "Approved Successfully !!";
    } else {
        $_SESSION['msg'] = "Error: Could not approve";
    }
}
?>



<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Parent Approval</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
<?php include('includes/headerp.php');?>
<?php include('includes/menubarp.php');?>


<div class="content-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h1 class="page-head-line">Parent Approval</h1>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
                <div class="panel">
                    <!-- <div class="panel-heading">
                        Parent Approval
                    </div> -->
                    <font color="green" align="center"><?php echo htmlentities($_SESSION['msg']);?><?php echo htmlentities($_SESSION['msg']="");?></font>

                    <div class="panel-body">
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                            <label for="pincode">Enter Student's Pincode:</label>
                            <input type="text" name="pincode" id="pincode" required><br><br>
                            <div align='center'>
                            <input type="submit" name="submit" value="Show Details">
                            </div>
                            
                        </form><br><br>

                        <?php
                        if (isset($_POST['submit'])) {
                            $enteredPin = $_POST['pincode'];
                            $sql1 = "SELECT * from students where pincode = '$enteredPin'";
                            $sql2 = "SELECT students.StudentRegno, students.studentName,students.cgpa,students.CName,courseenrolls.semester
                            FROM students
                            INNER JOIN courseenrolls ON students.pincode = courseenrolls.pincode
                            WHERE courseenrolls.pincode = '$enteredPin' AND courseenrolls.parent = 0";
                            $result1 = mysqli_query($bd, $sql1);
                            if($result1){
                                $result2 = mysqli_query($bd, $sql2);
                                if (mysqli_num_rows($result2) > 0) {
                                    ?>
                                    <div class="panel panel-default" style="width: 120%;">
                                        <div class="panel-heading">
                                            Students Details of <?php echo $enteredPin; ?>
                                        </div>
                                        <div class="panel-body">
                                        <div class="table-bordered">
                                        <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Reg No.</th>
                                                        <th>Student Name</th>
                                                        <th>Semester</th>
                                                        <th>CGPA</th>
                                                        <th>Counselor</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $cnt = 1;
                                                    while ($row = mysqli_fetch_assoc($result2)) {
                                                        ?>
                                                        <tr>
                                                            <td><?php echo $cnt; ?></td>
                                                            <td><?php echo htmlentities($row['StudentRegno']); ?></td>
                                                            <td><?php echo htmlentities($row['studentName']); ?></td>
                                                            <td><?php echo htmlentities($row['semester']); ?></td>
                                                            <td><?php echo htmlentities($row['cgpa']); ?></td>
                                                            <td><?php echo htmlentities($row['CName']); ?></td>
                                                            <td>
                                                                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                                                    <input type="hidden" name="studentRegno" value="<?php echo htmlentities($row['StudentRegno']); ?>">
                                                                    <input type="submit" name="approve" value="Approve">
                                                                </form>
                                                            </td>
                                                        </tr>
                                                        <?php
                                                        $cnt++;
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <?php
                                }
                            
                            else{
                                $_SESSION['msg'] = "Invalid PIN or Approved Already";
                            } 
                        }
                    }
                   
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.11.1.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script>
    function userAvailability() {
        $("#loaderIcon").show();
        jQuery.ajax({
            url: "check_availability.php",
            data:'regno='+$("#studentregno").val(),
            type: "POST",
            success:function(data){
                $("#user-availability-status1").html(data);
                $("#loaderIcon").hide();
            },
            error:function (){}
        });
    }
    </script>
</body>
</html>
<?php  ?>
