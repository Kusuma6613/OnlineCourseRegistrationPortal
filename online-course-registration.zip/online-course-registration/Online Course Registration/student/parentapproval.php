<?php
session_start();
include('includes/config.php');

if(isset($_POST['submit'])) {
    $pincode = $_POST['pincode'];

    // Retrieve data based on the entered pincode
    $query = "SELECT * FROM students WHERE ParentPincode = '$pincode'";
    $result = mysqli_query($bd, $query);

    if(mysqli_num_rows($result) > 0) {
        $_SESSION['pincode'] = $pincode;
        $_SESSION['student_data'] = mysqli_fetch_assoc($result);
    } else {
        $_SESSION['error'] = "Invalid Pincode!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Parent Approval</title>
    <!-- Add your CSS and other meta tags -->
</head>
<body>

    <h1>Parent Approval</h1>

    <?php if(isset($_SESSION['error'])): ?>
        <div><?php echo $_SESSION['error']; ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php endif; ?>

    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
        <label for="pincode">Enter Child's Pincode:</label><br>
        <input type="text" id="pincode" name="pincode" required><br><br>
        <input type="submit" name="submit" value="Submit">
    </form>

    <?php if(isset($_SESSION['student_data'])): ?>
        <h2>Student Details:</h2>
        <p>Student Name: <?php echo $_SESSION['student_data']['StudentName']; ?></p>
        <p>Student Reg No.: <?php echo $_SESSION['student_data']['StudentRegno']; ?></p>
        <!-- Add more details to display -->
        
        <!-- Here you can add an approval button -->
        <!-- For example: -->
        <form method="post" action="process_approval.php">
            <input type="hidden" name="student_id" value="<?php echo $_SESSION['student_data']['id']; ?>">
            <input type="submit" name="approve" value="Approve">
        </form>
    <?php endif; ?>

</body>
</html>
