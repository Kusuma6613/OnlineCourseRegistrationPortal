<?php
session_start();
include('includes/config.php');
if (strlen($_SESSION['login']) == 0) {
    header('location:index.php');
} else {
    if (isset($_POST['submit'])) {
        // Update student record
        $studentname = $_POST['studentname'];
        $photo = $_FILES["photo"]["name"];
        $cgpa = $_POST['cgpa'];
        $cname = $_POST['cname'];
        $sem = $_POST['semester'];

        // Move uploaded photo to a directory
        move_uploaded_file($_FILES["photo"]["tmp_name"], "studentphoto/" . $_FILES["photo"]["name"]);

        $ret = mysqli_query($bd, "UPDATE students SET studentName='$studentname', studentPhoto='$photo', cgpa='$cgpa', CName='$cname', semester='$sem' WHERE StudentRegno='" . $_SESSION['login'] . "'");

        if ($ret) {
            $_SESSION['msg'] = "Student Record updated Successfully !!";
        } else {
            $_SESSION['msg'] = "Error: Student Record not updated";
        }
    }
}
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <title>Student Profile</title>
    <!-- Include your CSS links here -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
    <?php include('includes/header.php'); ?>
    <?php if ($_SESSION['login'] != "") {
        include('includes/menubar.php');
    }
    ?>

    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-head-line">Student Registration </h1>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Student Registration
                        </div>
                        <font color="green" align="center"><?php echo htmlentities($_SESSION['msg']); ?><?php echo htmlentities($_SESSION['msg'] = ""); ?></font>
                        <?php $sql = mysqli_query($bd, "SELECT * FROM students WHERE StudentRegno='" . $_SESSION['login'] . "'");
                        $cnt = 1;
                        while ($row = mysqli_fetch_array($sql)) { ?>
                            <div class="panel-body">
                                <form name="dept" method="post" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="studentname">Student Name</label>
                                        <input type="text" class="form-control" id="studentname" name="studentname" value="<?php echo htmlentities($row['studentName']); ?>" />
                                    </div>
                                    <div class="form-group">
                                        <label for="studentregno">Student Reg No</label>
                                        <input type="text" class="form-control" id="studentregno" name="studentregno" value="<?php echo htmlentities($row['StudentRegno']); ?>" placeholder="Student Reg no" readonly />
                                    </div>
                                    <div class="form-group">
                                        <label for="CGPA">CGPA</label>
                                        <input type="text" class="form-control" id="cgpa" name="cgpa" value="<?php echo htmlentities($row['cgpa']); ?>" required />
                                    </div>
                                    <div class="form-group">
                                        <label for="studentphoto">Student Photo</label>
                                        <?php if ($row['studentPhoto'] == "") { ?>
                                            <img src="studentphoto/noimage.png" width="200" height="200">
                                        <?php } else { ?>
                                            <img src="studentphoto/<?php echo htmlentities($row['studentPhoto']); ?>" width="200" height="200">
                                        <?php } ?>
                                    </div>
                                    <div class="form-group">
                                        <label for="photo">Upload New Photo</label>
                                        <input type="file" class="form-control" id="photo" name="photo" value="<?php echo htmlentities($row['studentPhoto']); ?>" />
                                    </div>
                                    <div class="form-group">
                                        <label for="semester">Semester</label>
                                        <select class="form-control" id="semester" name="semester" required>
                                            <?php
                                            $semesterQuery = mysqli_query($bd, "SELECT semester FROM semester");
                                            while ($semesterRow = mysqli_fetch_assoc($semesterQuery)) {
                                                $selected = ($semesterRow['semester'] == $row['semester']) ? 'selected' : '';
                                                echo "<option value='{$semesterRow['semester']}' $selected>{$semesterRow['semester']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label for="cname">Counselor</label>
                                        <select class="form-control" id="cname" name="cname" required>
                                            <?php
                                            $counselorQuery = mysqli_query($bd, "SELECT CName FROM counselor");
                                            while ($counselorRow = mysqli_fetch_assoc($counselorQuery)) {
                                                $selected = ($counselorRow['CName'] == $row['CName']) ? 'selected' : '';
                                                echo "<option value='{$counselorRow['CName']}' $selected>{$counselorRow['CName']}</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <button type="submit" name="submit" id="submit" class="btn btn-default">Update</button>
                                </form>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include('includes/footer.php'); ?>
    <!-- Include your JS scripts here -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <script src="assets/js/bootstrap.js"></script>
</body>

</html>
