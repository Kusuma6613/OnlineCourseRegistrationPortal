<?php
session_start();
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}

?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Admin | Course</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
<?php include('includes/header.php');?>
   
<?php if($_SESSION['alogin']!="")
{
 include('includes/menubar.php');
}
 ?>
   
    <div class="content-wrapper">
    <div class="container" id="wrapper">
		<div class="row">
			<div class="col-md-3" id="sidebar">

				
			</div>
			<div class="col-md-9">
				<div id="main-area">
					<div class="content-section">
                    <h5>Search Results:</h5><br>
                        <?php
                        // Check if the 'query' parameter is present in the URL
                        if (isset($_GET['query'])) {
							
                            // Get and sanitize the search query from the URL
                            $searchQuery = urldecode($_GET['query']);
							                            // Construct and execute a SQL query to search for data in your database
							//$escapedQuery->real_escape_string($searchQuery);
							//echo $escapedQuery;
							$sql1 = mysqli_query($bd, "SELECT
                                                        ce.course AS cid,
                                                        c.courseName AS courname,
                                                        ce.enrollDate AS edate,
                                                        s.semester AS sem,
                                                        st.studentName AS sname,
                                                        st.StudentRegno AS sregno,
                                                        st.CName as coun
                                                    FROM
                                                        courseenrolls ce
                                                    JOIN course c ON c.courseName = ce.course
                                                    JOIN semester s ON s.id = ce.semester
                                                    JOIN students st ON st.StudentRegno = ce.studentRegno
                                                    WHERE
                                                        ce.parent = 1
                                                    AND ce.counselor = 1 
                                                    AND st.StudentRegno = '$searchQuery'");
                            $sql2 = mysqli_query($bd, "SELECT
                                                            ce.course AS cid,
                                                            c.courseName AS courname,
                                                            ce.enrollDate AS edate,
                                                            s.semester AS sem,
                                                            st.studentName AS sname,
                                                            st.StudentRegno AS sregno,
                                                            st.CName as coun
                                                        FROM
                                                            courseenrolls ce
                                                        JOIN course c ON c.courseName = ce.course
                                                        JOIN semester s ON s.id = ce.semester
                                                        JOIN students st ON st.StudentRegno = ce.studentRegno
                                                        WHERE
                                                            ce.parent = 1
                                                        AND ce.counselor = 1 
                                                        AND st.studentName = '$searchQuery'");
                            $sql3 = mysqli_query($bd, "SELECT
                                                            ce.course AS cid,
                                                            c.courseName AS courname,
                                                            ce.enrollDate AS edate,
                                                            s.semester AS sem,
                                                            st.studentName AS sname,
                                                            st.StudentRegno AS sregno,
                                                            st.CName as coun
                                                        FROM
                                                            courseenrolls ce
                                                        JOIN course c ON c.courseName = ce.course
                                                        JOIN semester s ON s.id = ce.semester
                                                        JOIN students st ON st.StudentRegno = ce.studentRegno
                                                        WHERE
                                                            ce.parent = 1
                                                        AND ce.counselor = 1 
                                                        AND c.courseName = '$searchQuery'");
                            $sql4 = mysqli_query($bd, "SELECT
                                                            ce.course AS cid,
                                                            c.courseName AS courname,
                                                            ce.enrollDate AS edate,
                                                            s.semester AS sem,
                                                            st.studentName AS sname,
                                                            st.StudentRegno AS sregno,
                                                            st.CName as coun
                                                        FROM
                                                            courseenrolls ce
                                                        JOIN course c ON c.courseName = ce.course
                                                        JOIN semester s ON s.id = ce.semester
                                                        JOIN students st ON st.StudentRegno = ce.studentRegno
                                                        WHERE
                                                            ce.parent = 1
                                                        AND ce.counselor = 1 
                                                        AND ce.semester = '$searchQuery'");
							
                            $cnt=1;
							if($sql1->num_rows > 0) {
								echo "<br><h5>Details: </h5><br>";
                                #	Reg No	Student Name	Pincode	Counselor	Reg Date	Action
								if ($sql1->num_rows > 0) {
									echo "<table border = 5 class='table'>";
									echo "<thead>";
									echo "<tr>";
									echo "<th>#</th>";
									echo "<th>Student Name</th>";
                                    echo "<th>Reg No</th>";
									echo "<th>Course Name</th>";
									echo "<th>Semester</th>";
									echo "<th>Reg Date</th>";
									echo "</tr>";
									echo "</thead>";
									echo "<tbody>";
								
									while ($row = $sql1->fetch_assoc()) {
										echo "<tr>";
										
										echo "<td>" . $cnt . "</td>";
										echo "<td>" . $row['sregno'] . "</td>";
										echo "<td>" . $row['sname'] . "</td>";
										echo "<td>" . $row['courname'] . "</td>";
										echo "<td>" . $row['coun'] . "</td>";
										echo "<td>" . $row['edate'] . "</td>";
										echo "</tr>";

                                        $cnt++;
									 }
								
									echo "</tbody>";
									echo "</table>";
								} else {
									echo "<p>No results found for your search query.</p>";
								}
							}
							else if($sql2->num_rows > 0){
								if ($sql2->num_rows > 0) {
									echo "<table border = 5 class='table'>";
									echo "<thead>";
									echo "<tr>";
									echo "<th>#</th>";
									echo "<th>Student Name</th>";
                                    echo "<th>Reg No</th>";
									echo "<th>Course Name</th>";
									echo "<th>Semester</th>";
									echo "<th>Reg Date</th>";
									echo "</tr>";
									echo "</thead>";
									echo "<tbody>";
								
									while ($row = $sql2->fetch_assoc()) {
										echo "<tr>";
										
										echo "<td>" . $cnt . "</td>";
										echo "<td>" . $row['sregno'] . "</td>";
										echo "<td>" . $row['sname'] . "</td>";
										echo "<td>" . $row['courname'] . "</td>";
										echo "<td>" . $row['coun'] . "</td>";
										echo "<td>" . $row['edate'] . "</td>";
										echo "</tr>";

                                        $cnt++;
									 }
								
									echo "</tbody>";
									echo "</table>";
								} 
                            }
                                else if($sql3->num_rows > 0){
                                    if ($sql3->num_rows > 0) {
                                        echo "<table border = 5 class='table'>";
                                        echo "<thead>";
                                        echo "<tr>";
                                        echo "<th>#</th>";
                                        echo "<th>Student Name</th>";
                                        echo "<th>Reg No</th>";
                                        echo "<th>Course Name</th>";
                                        echo "<th>Semester</th>";
                                        echo "<th>Reg Date</th>";
                                        echo "</tr>";
                                        echo "</thead>";
                                        echo "<tbody>";
                                    
                                        while ($row = $sql3->fetch_assoc()) {
                                            echo "<tr>";
                                            
                                            echo "<td>" . $cnt . "</td>";
                                            echo "<td>" . $row['sregno'] . "</td>";
                                            echo "<td>" . $row['sname'] . "</td>";
                                            echo "<td>" . $row['courname'] . "</td>";
                                            echo "<td>" . $row['coun'] . "</td>";
                                            echo "<td>" . $row['edate'] . "</td>";
                                            echo "</tr>";
    
                                            $cnt++;
                                         }
                                    
                                        echo "</tbody>";
                                        echo "</table>";
                                    } 
                                }
                                    else if($sql4->num_rows > 0){
                                        if ($sql4->num_rows > 0) {
                                            echo "<table border = 5 class='table'>";
                                            echo "<thead>";
                                            echo "<tr>";
                                            echo "<th>#</th>";
                                            echo "<th>Student Name</th>";
                                            echo "<th>Reg No</th>";
                                            echo "<th>Course Name</th>";
                                            echo "<th>Semester</th>";
                                            echo "<th>Reg Date</th>";
                                            echo "</tr>";
                                            echo "</thead>";
                                            echo "<tbody>";
                                        
                                            while ($row = $sql4->fetch_assoc()) {
                                                echo "<tr>";
                                                
                                                echo "<td>" . $cnt . "</td>";
                                                echo "<td>" . $row['sregno'] . "</td>";
                                                echo "<td>" . $row['sname'] . "</td>";
                                                echo "<td>" . $row['courname'] . "</td>";
                                                echo "<td>" . $row['coun'] . "</td>";
                                                echo "<td>" . $row['edate'] . "</td>";
                                                echo "</tr>";
        
                                                $cnt++;
                                             }
                                        
                                            echo "</tbody>";
                                            echo "</table>";
                                        }
						}
                        else {
                            echo "<p>No results found for your search query.</p>";
                        }
                    }
						?>

					</div> <!-- Content Section End -->
                    <br><br>
					
			</div>
		</div>
    </div>
    
  <?php include('includes/footer.php');?>
    
    <script src="assets/js/jquery-1.11.1.js"></script>
    
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>
<?php  ?>