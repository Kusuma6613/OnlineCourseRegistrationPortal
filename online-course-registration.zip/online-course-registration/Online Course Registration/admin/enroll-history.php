<?php
session_start();
include('includes/config.php');
if(strlen($_SESSION['alogin']) == 0) {
    header('location:index.php');
} else {
?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Enroll History</title>
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
</head>

<body>
    <?php include('includes/header.php');?>

    <?php if($_SESSION['alogin']!="") {
        include('includes/menubar.php');
    } ?>

    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1 class="page-head-line">Enroll History</h1>
                </div>
            </div>
            <form action="ds2.php" align = "center;" method="GET">
							<div class="col-md-6 offset-md-3">
								<input type="text" align = "center" class="form-control" id="search" name="query" placeholder="Search" required autocomplete="off">
								<div align = "center" class="input-group-prepend"><br>
									<button type="submit" class="btn btn-default" align = "center">
										<i class="fal fa-search" align = "center" id="searchPrepend" style="cursor: pointer;"></i>
									</button><br><br>
									<script>
										// Get the <i> element by its id
										var searchIcon = document.getElementById('searchPrepend');

										// Add a click event listener to the icon
										searchIcon.addEventListener('click', function() {
											// Redirect to the desired URL
											window.location.href = 'ds2.php';
										});

										// Add a keydown event listener to listen for the Enter key press
										document.addEventListener('keydown', function(event) {
											if (event.key === 'Enter') {
												// Simulate a click on the icon
												searchIcon.click();
											}
										});
									</script>
								</div>
							</div>
						</form>
            <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                           Enroll History
                        </div> 
                        <div class="panel-body">
                            <?php
                            $sql = mysqli_query($bd, "SELECT
                                                    ce.course AS courname,
                                                    ce.enrollDate AS edate,
                                                    ce.semester AS sem,
                                                    st.studentName AS sname,
                                                    st.StudentRegno AS sregno
                                                FROM
                                                    courseenrolls ce
                                                JOIN students st ON st.StudentRegno = ce.studentRegno
                                                WHERE
                                                    ce.parent = 1
                                                AND ce.counselor = 1;");

                            // Check if the query returned any results
                            if (mysqli_num_rows($sql) > 0) {
                                ?>
                                <div class="table-responsive table-bordered">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Student Name</th>
                                                <th>Student Reg no</th>
                                                <th>Course Name</th>
                                                <th>Semester</th>
                                                <th>Enrollment Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $cnt = 1;
                                            while($row = mysqli_fetch_array($sql)) {
                                            ?>
                                            <tr>
                                                <td><?php echo $cnt;?></td>
                                                <td><?php echo htmlentities($row['sname']);?></td>
                                                <td><?php echo htmlentities($row['sregno']);?></td>
                                                <td><?php echo htmlentities($row['courname']);?></td>                                          
                                                <td><?php echo htmlentities($row['sem']);?></td>
                                                <td><?php echo htmlentities($row['edate']);?></td>
                                            </tr>
                                            <?php
                                                $cnt++;
                                            } ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php
                            } else {
                                // No results were found
                                echo "No results found.";
                            }
                            ?>
                        </div>
                    </div>
                    <a href="print.php?id=<?php echo $row['cid']?>" target="_blank">
<button class="btn btn-primary"><i class="fa fa-print "></i> Print</button> </a>   <br><br>
                </div>
            </div>
        </div>
    </div>

    <?php include('includes/footer.php');?>
    <script src="assets/js/jquery-1.11.1.js"></script>
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>

<?php } ?>
