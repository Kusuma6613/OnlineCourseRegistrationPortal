<?php
session_start();
$_SESSION['alogin']=="";
session_unset();

$_SESSION['errmsg']="You have successfully logout";
?>
<script language="javascript">
document.location="http://localhost/online-course-registration/Online%20Course%20Registration/index.php";
</script>
